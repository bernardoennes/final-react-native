import { View } from "react-native";
import Blackjack from "./screens/blackjack/blackjack";
import Login from "./screens/login/Login"

function App() {
  return (
    <View>
      < Login />
    </View>
  );
}

export default App;
